# Open WebUI บน GitHub Codespaces (ใช้ส่วนตัว)

1. ตั้ง Codespaces secret: `AI_API_KEY` (และ `WEBUI_SECRET_KEY` ถ้าต้องการ)
   GitHub → Settings → Codespaces → New secret → เลือก repo นี้
2. Code → Codespaces → Create codespace on main
3. รอให้ขึ้น ✅ แล้วเปิดแท็บ PORTS → กดลูกโลกที่พอร์ต 3000
4. สมัครบัญชีแรก (จะเป็นแอดมิน) แล้วไปปิด Enable New Sign Ups
5. โมเดล: ant/gpt-oss-120b

ถ้าเว็บไม่ขึ้น: `bash .devcontainer/start.sh`
ดู log: `docker logs -f open-webui`
