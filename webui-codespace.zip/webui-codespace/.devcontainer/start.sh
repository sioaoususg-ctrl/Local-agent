#!/usr/bin/env bash
set -e
cd "$(dirname "$0")/.."

if [ -z "$AI_API_KEY" ]; then
  echo "⚠️  ยังไม่ได้ตั้ง Codespaces secret ชื่อ AI_API_KEY"
  echo "   ไป GitHub > Settings > Codespaces > New secret แล้ว Rebuild Container"
  exit 0
fi

# ถ้าไม่ได้ตั้ง WEBUI_SECRET_KEY ให้สุ่มแล้วจำไว้ในไฟล์ (ไม่ขึ้น git)
if [ -z "$WEBUI_SECRET_KEY" ]; then
  [ -f .webui_secret ] || head -c 32 /dev/urandom | base64 > .webui_secret
  export WEBUI_SECRET_KEY="$(cat .webui_secret)"
fi

docker compose up -d
echo "✅ Open WebUI กำลังเริ่มทำงาน เปิดแท็บ PORTS แล้วกดลูกโลกที่พอร์ต 3000"
